from django.shortcuts import render,HttpResponse
# importing libraries
import pandas as pd
import numpy as np

# function for finding Sales Growth percentage....
def func(a,b):
    if b==0:
        return str("")  
    else:
        return str(     round(((a/b)-1)*100 , 1)   ) + '%'

# index function for request
def index(request):
    # processing the table  

    df = pd.read_csv("Assignment-Business-Quant.csv")
    df=df.sort_values(by=['Item','Year'])
    df['Sales Last Year'] = df.groupby('Item')['Sales'].shift(periods=1,fill_value = 0)
    df['Sales Growth %'] = df.apply( lambda row : func( row['Sales'], row['Sales Last Year']  ) , axis = 1  )
    df.loc[df['Sales Last Year']==0 , 'Sales Last Year']= ""
    checklist = df['Item'].unique()
    items=[]

    # Filtering the table according to the given request
    if request.method == "POST":
        items = request.POST.getlist('items')
        if len(items)>0:
            df = df[df['Item'].isin(items)]
        

    
    df.rename(columns = {'Sales Last Year':'Sales_Last_Year', 'Sales Growth %':'Sales_Growth'}, inplace = True)
    df=df.to_dict('records')
    mydict={
        "data" : df ,
        "checklist" : checklist,
        "ch_items" : items}

    #render the output
    return render(request, 'index.html',context=mydict)

