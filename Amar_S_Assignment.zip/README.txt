Assignment is done by Amar S Sajjanshetty

1) The project file is assign
2) The code is written in .../hello/views.py 
3) The HTML file for the output is written in .../templates/index.html
4) The sample output screenshot is also been attached for your reference. 